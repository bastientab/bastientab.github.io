import sys,json,asyncio,subprocess
from pathlib import Path
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE/'video-deps'))
import edge_tts,imageio_ffmpeg
sys.stdout.reconfigure(encoding='utf-8')
voice=sys.argv[1] if len(sys.argv)>1 else 'fr-FR-DeniseNeural'
items=json.loads((BASE/'arithmetique-narration.json').read_text(encoding='utf-8'))
DEST=BASE/('video-arithmetique-'+voice)
DEST.mkdir(exist_ok=True)
async def render(item):
 target=DEST/(item['id']+'.mp3')
 if not target.exists():
  timings=[]
  comm=edge_tts.Communicate(item['text'],voice,rate='-5%')
  with target.with_suffix('.partial').open('wb') as f:
   async for chunk in comm.stream():
    if chunk['type']=='audio':f.write(chunk['data'])
    elif chunk['type'] in ('WordBoundary','SentenceBoundary'):timings.append({k:v for k,v in chunk.items() if k!='type'})
  target.with_suffix('.partial').replace(target)
  target.with_suffix('.timing.json').write_text(json.dumps(timings,ensure_ascii=False),encoding='utf-8')
 if not target.with_suffix('.wav').exists():
  subprocess.run([imageio_ffmpeg.get_ffmpeg_exe(),'-y','-v','error','-i',str(target),'-ar','24000','-ac','1',str(target.with_suffix('.wav'))],check=True)
async def main():
 semaphore=asyncio.Semaphore(2)
 completed=0
 async def worker(item):
  nonlocal completed
  async with semaphore:
   for attempt in range(3):
    try:
     await render(item)
     break
    except (edge_tts.exceptions.NoAudioReceived,TimeoutError) as exc:
     if attempt==2:raise
     print('Nouvel essai pour le paragraphe '+item['id'],flush=True)
     await asyncio.sleep(2*(attempt+1))
   completed+=1
   if completed%10==0 or completed==len(items):print(f'{completed}/{len(items)} paragraphes, voix {voice}',flush=True)
 await asyncio.gather(*(worker(item) for item in items))
 (DEST/'voice.json').write_text(json.dumps({'voice':voice,'rate':'-5%','timing':'SentenceBoundary'},indent=2),encoding='utf-8')
asyncio.run(main())
