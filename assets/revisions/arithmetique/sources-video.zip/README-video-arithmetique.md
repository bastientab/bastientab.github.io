# Vidéo d’arithmétique — sources modifiables

La narration est rédigée dans `arithmetique-narration.json`, avec un paragraphe par segment. Les explications et les contenus affichés au tableau sont dans `arithmetique-course.json`. Les visuels sont dessinés par `render-course-video.py`.

La voix retenue par Bastien est **fr-FR-VivienneMultilingualNeural**. La première voix Windows a été écartée ; ne pas réutiliser cette version. La narration indique qu’il s’agit d’une voix de synthèse.

## Reproduire le rendu sur Windows

Python doit disposer de Pillow, reportlab, imageio-ffmpeg et edge-tts. Dans la session d’origine, ces dépendances sont séparées dans `work/video-deps` ; le dossier du script doit donc contenir `video-deps`, ou les dépendances doivent être installées dans l’environnement Python employé.

1. Exécuter `python narrate-natural.py fr-FR-VivienneMultilingualNeural` pour générer ou compléter la narration. Les paragraphes déjà présents sont conservés. Cette étape envoie le texte rédigé au service vocal en ligne de Microsoft.
2. Exécuter `python render-course-video.py --voice=fr-FR-VivienneMultilingualNeural`.
3. Récupérer le MP4, l’affiche, les sous-titres, la transcription et le chapitrage dans `revisions-site/assets/revisions/arithmetique`.

Le rendu utilise une image progressive par paragraphe et deux images par seconde dans le MP4. L’audio est assemblé sur les durées réellement générées. Les sous-titres sont alignés sur les limites de phrase fournies par le service vocal ; les limites internes des groupes de mots sont estimées. Ils restent donc à ajuster manuellement si un synchronisme mot à mot est nécessaire.

Le support de cours et les fichiers TD/TP originaux sont conservés à part dans une compilation privée ; ils ne font pas partie de cette archive publiée.
