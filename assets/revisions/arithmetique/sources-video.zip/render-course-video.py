"""Rendu local, narration Windows séparée ; images progressives et sous-titres."""
import sys, json, wave, subprocess, textwrap, re
from pathlib import Path
sys.stdout.reconfigure(encoding='utf-8')
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE/'video-deps'))
import imageio_ffmpeg
from PIL import Image,ImageDraw,ImageFont
from reportlab.pdfbase.ttfonts import TTFont
from functools import lru_cache
FFMPEG=imageio_ffmpeg.get_ffmpeg_exe()
COURSE=json.loads((BASE/'arithmetique-course.json').read_text(encoding='utf-8'))
DEST=BASE/'revisions-site/assets/revisions/arithmetique'
DEST.mkdir(parents=True,exist_ok=True)
VOICE=next((a.split('=',1)[1] for a in sys.argv if a.startswith('--voice=')),None)
FONT=Path('C:/Windows/Fonts')
CMAPS={name:TTFont(name,str(FONT/name)).face.charToGlyph for name in ['segoeuib.ttf','segoeui.ttf']}
@lru_cache(maxsize=20)
def font(size,bold=False):
 return ImageFont.truetype(str(FONT/('segoeuib.ttf' if bold else 'segoeui.ttf')),size)
@lru_cache(maxsize=10)
def symbolfont(size):return ImageFont.truetype(str(FONT/'seguisym.ttf'),size)
def textruns(text,f):
 cmap=CMAPS[Path(f.path).name]
 runs=[]
 for char in text:
  selected=f if ord(char) in cmap else symbolfont(f.size)
  if runs and runs[-1][0] is selected:runs[-1][1]+=char
  else:runs.append([selected,char])
 return runs
def textwidth(draw,text,f):return sum(draw.textlength(t,font=ff) for ff,t in textruns(text,f))
def richtext(draw,xy,text,f,fill):
 x,y=xy
 for ff,t in textruns(text,f):
  draw.text((x,y),t,font=ff,fill=fill)
  x+=draw.textlength(t,font=ff)
def wrap(draw,text,f,width):
 lines=[]; line=''
 for word in text.split():
  test=(line+' '+word).strip()
  if textwidth(draw,test,f)>width and line:
   lines.append(line); line=word
  else: line=test
 if line:lines.append(line)
 return lines
def frame(ch,sc,stage,number,total,destination):
 im=Image.new('RGB',(1280,720),'#f5f5f7'); d=ImageDraw.Draw(im)
 purple='#635bff';ink='#202128';muted='#656575'
 d.rounded_rectangle((42,34,1238,686),radius=26,fill='white',outline='#e0e0e8',width=2)
 d.rounded_rectangle((70,60,405,103),radius=18,fill='#efedff')
 d.text((88,67),'BUT2 R&T · Arithmétique',font=font(22,True),fill=purple)
 d.text((1020,69),f'{number:02d} / {total:02d}',font=font(22),fill=muted)
 y=132
 for line in wrap(d,ch['title'],font(32,True),1100):
  d.text((78,y),line,font=font(32,True),fill=ink);y+=41
 d.text((78,y+8),sc['title'],font=font(24),fill=muted)
 y+=68
 for i,point in enumerate(sc['board']):
  if i>stage:continue
  lines=wrap(d,point,font(30,True),1020)
  h=24+len(lines)*40
  d.rounded_rectangle((78,y,1202,y+h),radius=15,fill='#f2f0ff' if i==min(stage,len(sc['board'])-1) else '#f7f7fa')
  d.text((94,y+13),str(i+1),font=font(23,True),fill=purple)
  for line in lines:
   richtext(d,(135,y+10),line,font(30,True),ink);y+=40
  y+=35
 if y>630:raise ValueError('Visuel trop rempli : '+sc['title'])
 d.line((78,639,1202,639),fill='#e0e0e8',width=2)
 d.text((78,655),'bastientabordet.fr/menu · Voix de synthèse française',font=font(18),fill=muted)
 im.save(destination)
def duration(wav):
 with wave.open(str(wav),'rb') as w:return w.getnframes()/w.getframerate()
def clock(t):
 ms=round(t*1000);h,ms=divmod(ms,3600000);m,ms=divmod(ms,60000);s,ms=divmod(ms,1000)
 return f'{h:02}:{m:02}:{s:02}.{ms:03}'
def render(preview=False):
 work=BASE/('video-preview' if preview else 'video-arithmetique'+('-'+VOICE if VOICE else '')); work.mkdir(exist_ok=True)
 if preview:
  cues=json.loads((BASE/'voice-preview.json').read_text(encoding='utf-8'))
  cues[0].update(chapter=0,scene=0,paragraph=0)
 else:cues=json.loads((BASE/'arithmetique-narration.json').read_text(encoding='utf-8'))
 clips=[]; offset=0; subtitles=['WEBVTT','']; transcript=[]; chaptermarks=[];audiofiles=[]
 scenes=[(i,j) for i,c in enumerate(COURSE['chapters']) for j,_ in enumerate(c['scenes'])]
 for cue in cues:
  wav=work/(cue['id']+'.wav'); dur=duration(wav);audiofiles.append(wav)
  ci,si=cue['chapter'],cue['scene'];ch=COURSE['chapters'][ci];sc=ch['scenes'][si]
  if not chaptermarks or chaptermarks[-1]['index']!=ci:
   chaptermarks.append({'index':ci,'title':ch['title'],'start':offset})
   transcript.append('\n## '+ch['title']+'\n')
  if cue['paragraph']==0:transcript.append('\n### '+sc['title']+'\n')
  transcript.append(cue['text']+'\n')
  img=work/(cue['id']+'.png')
  paragraphs=len(sc['text'].split('\n\n'))
  stage=round(cue['paragraph']*(len(sc['board'])-1)/max(1,paragraphs-1))
  frame(ch,sc,stage,scenes.index((ci,si))+1,len(scenes),img)
  clips.append((img,dur))
  timingfile=work/(cue['id']+'.timing.json')
  sentences=json.loads(timingfile.read_text(encoding='utf-8')) if timingfile.exists() else []
  if not sentences:sentences=[{'text':cue['text'],'offset':0,'duration':dur*10000000}]
  for sentence in sentences:
   words=sentence['text'].split(); groups=[words[i:i+12] for i in range(0,len(words),12)]
   consumed=0;start=offset+sentence['offset']/10000000;span=sentence['duration']/10000000
   for group in groups:
    begin=start+span*consumed/len(words);consumed+=len(group);end=min(offset+dur,start+span*consumed/len(words))
    line=' '.join(group)
    subtitles.extend([f'{clock(begin)} --> {clock(end)}','\n'.join(textwrap.wrap(line,60)),''])
  offset+=dur
 fullwave=work/'narration.wav'
 with wave.open(str(audiofiles[0]),'rb') as first:
  params=first.getparams()
 with wave.open(str(fullwave),'wb') as target:
  target.setparams(params)
  for wav in audiofiles:
   with wave.open(str(wav),'rb') as source:target.writeframes(source.readframes(source.getnframes()))
 listing=work/'images.txt'
 listing.write_text(''.join(f"file '{p.as_posix()}'\nduration {dur:.6f}\n" for p,dur in clips)+f"file '{clips[-1][0].as_posix()}'\n",encoding='utf-8')
 output=work/'extrait.mp4' if preview else DEST/'cours-video.mp4'
 cmd=[FFMPEG,'-y','-hide_banner','-loglevel','warning','-f','concat','-safe','0','-i',str(listing),'-i',str(fullwave),'-vf','fps=2','-c:v','libx264','-preset','fast','-tune','stillimage','-crf','24','-pix_fmt','yuv420p','-c:a','aac','-b:a','56k','-ar','22050','-movflags','+faststart','-t',str(offset),str(output)]
 print('Rendu :',len(cues),'paragraphes ; durée',round(offset/60,2),'minutes',flush=True)
 subprocess.run(cmd,check=True)
 if not preview:
  (DEST/'sous-titres.vtt').write_text('\n'.join(subtitles),encoding='utf-8')
  (DEST/'transcription.md').write_text('# Transcription — Arithmétique pour la cryptographie\n\nVoix de synthèse : '+(VOICE or 'Microsoft Hortense Desktop')+'. Sous-titres alignés sur les phrases du service vocal ; découpage des groupes de mots estimé.\n'+'\n'.join(transcript),encoding='utf-8')
  (DEST/'chapitres.json').write_text(json.dumps({'duration':offset,'chapters':chaptermarks},ensure_ascii=False,indent=2),encoding='utf-8')
  Image.open(clips[0][0]).save(DEST/'video-affiche.jpg',quality=92)
 (work/'rendu.json').write_text(json.dumps({'duration':offset,'file':str(output),'bytes':output.stat().st_size,'paragraphs':len(cues),'voice':VOICE or 'Microsoft Hortense Desktop','caption_timing':'sentence-boundary; intra-sentence estimated'},indent=2),encoding='utf-8')
 print('Fichier final :',output,';',round(output.stat().st_size/1048576,1),'Mo',flush=True)
if __name__=='__main__':render('--preview' in sys.argv)
